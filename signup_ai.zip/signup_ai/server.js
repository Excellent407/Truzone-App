require("dotenv").config(); // Load .env in local dev

const express = require("express");
const bodyParser = require("body-parser");
const { checkBot } = require("./services/botDetection");
const { checkEmail } = require("./services/emailCheck");
const { checkPassword } = require("./services/passwordCheck");
const { checkDevice } = require("./services/deviceCheck");
const { generateCode } = require("./utils/generateCode");
const { sendEmail } = require("./utils/sendEmail");
const { Pool } = require("pg");

// ====== DATABASE CONNECTION ======
const pool = new Pool({
  connectionString: process.env.DATABASE_URL, // Railway injects this
  ssl: { rejectUnauthorized: false }
});

const app = express();
app.use(bodyParser.json());

// ====== SIGNUP ENDPOINT ======
app.post("/signup", async (req, res) => {
  try {
    const { firstName, lastName, email, password, deviceName, ip } = req.body;

    // 1. Bot check
    if (!checkBot(ip)) return res.status(400).json({ error: "Bot detected" });

    // 2. Email check
    if (!checkEmail(email)) return res.status(400).json({ error: "Invalid email" });

    // 3. Password check
    if (!checkPassword(password)) return res.status(400).json({ error: "Weak password" });

    // 4. Device/IP check
    if (!checkDevice(ip, deviceName)) return res.status(400).json({ error: "Suspicious device/IP" });

    // 5. Generate OTP
    const otp = generateCode();

    // 6. Send OTP via email
    await sendEmail(email, otp);

    // 7. Save user in PostgreSQL
    const result = await pool.query(
      `INSERT INTO users (first_name, last_name, email, password, ip_address, device_name) 
       VALUES ($1,$2,$3,$4,$5,$6) RETURNING id`,
      [firstName, lastName, email, password, ip, deviceName]
    );

    const userId = result.rows[0].id;

    // 8. Return success + OTP
    return res.json({
      message: "Signup success, verify email",
      userId,
      otp
    });

  } catch (err) {
    console.error("❌ Error in /signup:", err.message);
    return res.status(500).json({ error: "Server error" });
  }
});

// ====== SERVER LISTEN ======
const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`🚀 Signup AI running on port ${PORT}`));