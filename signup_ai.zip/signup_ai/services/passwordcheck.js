function checkPassword(password) {
  const strong = /^(?=.*[A-Z])(?=.*[a-z])(?=.*[0-9])(?=.*[@$!%*?&]).{8,}$/;
  return strong.test(password);
}

module.exports = { checkPassword };