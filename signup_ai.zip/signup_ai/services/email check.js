const disposableDomains = ["tempmail.com", "10minutemail.com", "mailinator.com"];

function checkEmail(email) {
  if (!email.includes("@")) return false;
  const domain = email.split("@")[1];
  if (disposableDomains.includes(domain)) return false;
  return true;
}

module.exports = { checkEmail };