let requestLog = {};

function checkBot(ip) {
  const now = Date.now();

  if (!requestLog[ip]) requestLog[ip] = [];
  requestLog[ip].push(now);

  // Keep only requests in last 10s
  requestLog[ip] = requestLog[ip].filter(t => now - t < 10000);

  // More than 5 requests in 10s = bot
  if (requestLog[ip].length > 5) return false;

  return true;
}

module.exports = { checkBot };