let deviceLog = {};

function checkDevice(ip, deviceName) {
  if (!deviceLog[ip]) deviceLog[ip] = new Set();
  deviceLog[ip].add(deviceName);

  // If too many devices on same IP → suspicious
  if (deviceLog[ip].size > 3) return false;

  return true;
}

module.exports = { checkDevice };