const { Pool } = require("pg");

const pool = new Pool({
  connectionString: process.env.DATABASE_URL, // Railway will provide this
  ssl: { rejectUnauthorized: false } // Required for Railway Postgres
});

module.exports = pool;