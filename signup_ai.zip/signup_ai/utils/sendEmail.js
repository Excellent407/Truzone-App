const nodemailer = require("nodemailer");

async function sendEmail(to, otp) {
  let transporter = nodemailer.createTransport({
    service: "gmail",
    auth: {
      user: "yourgmail@gmail.com",   // change this
      pass: "your_app_password"      // use Gmail App Password
    }
  });

  await transporter.sendMail({
    from: '"Truzone Signup" <yourgmail@gmail.com>',
    to,
    subject: "Verify your Truzone account",
    text: `Your OTP code is: ${otp}`
  });
}

module.exports = { sendEmail };